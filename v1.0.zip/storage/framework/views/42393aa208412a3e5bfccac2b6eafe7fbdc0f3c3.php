<?php $__env->startSection($section); ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount($component, $componentParameters)->dom;
} elseif ($_instance->childHasBeenRendered('fnvPGb4')) {
    $componentId = $_instance->getRenderedChildComponentId('fnvPGb4');
    $componentTag = $_instance->getRenderedChildComponentTagName('fnvPGb4');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fnvPGb4');
} else {
    $response = \Livewire\Livewire::mount($component, $componentParameters);
    $dom = $response->dom;
    $_instance->logRenderedChild('fnvPGb4', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aibnuhibban/Desktop/laralivewire/vendor/livewire/livewire/src/Macros/livewire-view.blade.php ENDPATH**/ ?>