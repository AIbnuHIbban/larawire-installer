<div>
    <nav class="navbar navbar-expand navbar-dark bg-dark" style="justify-content: center">
        <div class="nav navbar-nav">
            <a class="nav-item nav-link active" href="<?php echo e(url('livewire')); ?>">Home <span class="sr-only">(current)</span></a>
            <a class="nav-item nav-link" href="<?php echo e(url('about')); ?>">About</a>
        </div>
    </nav>
</div>
<?php /**PATH /home/aibnuhibban/Desktop/laralivewire/resources/views/livewire/navbar.blade.php ENDPATH**/ ?>