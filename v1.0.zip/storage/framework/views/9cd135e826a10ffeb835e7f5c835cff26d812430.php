<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Livewire Setup</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('navbar')->dom;
} elseif ($_instance->childHasBeenRendered('Nik6OqI')) {
    $componentId = $_instance->getRenderedChildComponentId('Nik6OqI');
    $componentTag = $_instance->getRenderedChildComponentTagName('Nik6OqI');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Nik6OqI');
} else {
    $response = \Livewire\Livewire::mount('navbar');
    $dom = $response->dom;
    $_instance->logRenderedChild('Nik6OqI', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    <?php echo $__env->yieldContent('content'); ?>
    
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH /home/aibnuhibban/Desktop/laralivewire/resources/views/livewire/app.blade.php ENDPATH**/ ?>