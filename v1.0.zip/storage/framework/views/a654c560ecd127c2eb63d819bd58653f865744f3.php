<div>
    <h1 class="text-center mt-5 text-danger font-weight-bold">Laravel + Livewire Setup</h1>
</div>
<?php /**PATH /home/aibnuhibban/Desktop/laralivewire/resources/views/livewire/example-component.blade.php ENDPATH**/ ?>