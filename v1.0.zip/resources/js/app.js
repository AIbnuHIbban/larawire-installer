require('./bootstrap');
var Turbolinks = require("turbolinks")
Turbolinks.start()