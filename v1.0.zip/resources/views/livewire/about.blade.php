<div>
    <h1 class="text-center font-weight-bold text-primary mt-5">Page About</h1>
</div>
