<div>
    <nav class="navbar navbar-expand navbar-dark bg-dark" style="justify-content: center">
        <div class="nav navbar-nav">
            <a class="nav-item nav-link active" href="{{url('livewire')}}">Home <span class="sr-only">(current)</span></a>
            <a class="nav-item nav-link" href="{{url('about')}}">About</a>
        </div>
    </nav>
</div>
