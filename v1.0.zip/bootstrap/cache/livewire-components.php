<?php return array (
  'about' => 'App\\Http\\Livewire\\About',
  'example-component' => 'App\\Http\\Livewire\\ExampleComponent',
  'navbar' => 'App\\Http\\Livewire\\Navbar',
);